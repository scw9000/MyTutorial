/*
  Copyright © 2020 Apple Pty Ltd. All rights reserved. Redistribution or public display not permitted without written permission from Apple.
  Created by Simon Wheatley on 20/7/20.
*/

import SwiftUI

struct NewCoffee: View {
    @ObservedObject var store: CoffeeStore
    @Environment(\.presentationMode) var presentationMode
    @State var showsAlert = false
    @State var name: String?
    @State var sugarCount = 0
    @State var coffeeSelection: coffeeType = .first
    @State var milkSelection: milkType = .first
    @State var sizeSelection: sizeType = .first
    
    var body: some View {
        NavigationView {
            Form {
                TextField("Your name", text: Binding(
                          get: { self.name ?? ""},
                          set: { self.name = $0 } )
                      )
                Picker("coffee", selection: $coffeeSelection) {
                    ForEach(coffeeType.allCases, id: \.id) { value in
                        Text(value.localizedName)
                            //.tag(value)
                    }
                }.pickerStyle(SegmentedPickerStyle())
                .padding(5)
  
                Picker("size", selection: $sizeSelection) {
                    ForEach(sizeType.allCases, id: \.id) { value in
                        Text(value.localizedName)
                           // .tag(value)
                    }
                }.pickerStyle(SegmentedPickerStyle())
                .padding(5)
                
                Picker("milk", selection: $milkSelection) {
                    ForEach(milkType.allCases, id: \.id) { value in
                        Text(value.localizedName)
                          //  .tag(value)
                    }
                }.pickerStyle(SegmentedPickerStyle())
                .padding(5)
                
                HStack {
                 if sugarCount == 0 {
                     Text("Sugar:")
                 }
                 else if sugarCount > 0 {
                     Text("Sugars:")
                 }
                 Spacer()
                 if sugarCount > 0 {
                     Text("\(sugarCount)")
                 }
                 Stepper("", value: $sugarCount)
                       .frame(width: 100, height: 35)
                       .offset(x: -4)
                       .background(Color.blue)
                       .cornerRadius(8)
                }
                
                HStack{
                    Spacer()
                    Button(action: {
                        //set the price:
                        var price = 0.0
                        switch(sizeSelection) {
                            case .first:  price = 3.0
                            case .second:  price = 4.0
                            case .third:  price = 4.5
                        }
                        //reset the milk to 'none' if americano:
                        if coffeeSelection == .first {
                            milkSelection = .third
                        }
                        
                        if let name = name {
                            let newCoffee = Coffee(name: name, milk: milkSelection.rawValue, sugar: sugarCount, isReady: "N", price: price, type: coffeeSelection.rawValue, size: sizeSelection.rawValue, created: Date())
                            store.coffees.append(newCoffee)
                            self.presentationMode.wrappedValue.dismiss()
                        }
                        else {
                            showsAlert = true
                        }
                    }) { Text("PlaceOrder") }
                    .alert(isPresented: self.$showsAlert) {
                        Alert(title: Text("MissingName"))
                    }
                    Spacer()
                }
            }
            .navigationBarTitle("New coffee order:")
        }
    }
    
}


struct NewCoffee_Previews: PreviewProvider {
    static var previews: some View {
        NewCoffee(store: testStore)
    }
}

