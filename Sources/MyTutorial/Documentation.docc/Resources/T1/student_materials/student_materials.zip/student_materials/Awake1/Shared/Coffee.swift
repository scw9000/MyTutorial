/*
  Copyright © 2020 Apple Pty Ltd. All rights reserved. Redistribution or public display not permitted without written permission from Apple.
  Created by Simon Wheatley on 20/7/20.
*/

import SwiftUI
import CloudKit

struct Coffee: Identifiable {
    var id = UUID()
    var name: String
    var milk: String
    var sugar: Int
    var isReady: String
    var price: Double
    var type: String
    var size: String
    var created: Date
    var thumb: String { return type+"_thumb" }
    
    let numberFormatter: NumberFormatter = {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        return numberFormatter
    }()
    
    var cost: String { return numberFormatter.string(from: (price as NSNumber))! }
}

let testData = [
    Coffee(name: "Pat", milk: "Full", sugar: 1, isReady: "N", price: 4.5, type: "Flat White", size: "Large", created: Date()),
    Coffee(name: "John", milk: "Skim", sugar: 0, isReady: "Y", price: 4.0, type: "Cappuccino", size: "Regular", created: Date())
]

enum coffeeType: String, Equatable, CaseIterable, Identifiable {
    case first  = "Americano"
    case second = "Cappuccino"
    case third  = "Latte"
    case fourth = "Flat White"
    var localizedName: LocalizedStringKey { LocalizedStringKey(rawValue) }
    var id: coffeeType {self}
}

enum milkType: String, Equatable, CaseIterable, Identifiable {
    case first  = "Full"
    case second = "Skim"
    case third  = "None"
    var localizedName: LocalizedStringKey { LocalizedStringKey(rawValue) }
    var id: milkType {self}
}

enum sizeType: String, Equatable, CaseIterable, Identifiable {
    case first  = "Small"
    case second = "Regular"
    case third  = "Large"
    var localizedName: LocalizedStringKey { LocalizedStringKey(rawValue) }
    var id: sizeType {self}
}
