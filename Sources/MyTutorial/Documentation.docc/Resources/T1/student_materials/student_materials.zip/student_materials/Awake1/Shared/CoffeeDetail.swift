/*
  Copyright © 2020 Apple Pty Ltd. All rights reserved. Redistribution or public display not permitted without written permission from Apple.
  Created by Simon Wheatley on 20/7/20.
*/

import SwiftUI

struct CoffeeDetail: View {
    var coffee : Coffee
    
    var body: some View {
        VStack {
            if coffee.isReady == "Y" {
                HStack{
                    Spacer()
                    Image(systemName: "checkmark.rectangle.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.green)
                        .frame(width: 50.0, height: 40.0)
                        .padding(.init(top: 0, leading: 0, bottom: -20, trailing: 15))
                        .zIndex(1)
                }
            }
            else {
                Spacer(minLength:0)
            }
            Image(coffee.type)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(15)
                .zIndex(-1)
            HStack {
                Spacer()
                Text(coffee.size + " " + coffee.type)
                    .font(.title2)
                Spacer()
            }.padding(10)
            
            if coffee.type != "Americano" {
                HStack {
                    Spacer()
                    Text("Milk: \(coffee.milk)")
                        .foregroundColor(Color.gray)
                    Spacer()
                }.padding(5)
            }
            if coffee.sugar > 0 {
                HStack {
                    Spacer()
                    Text("Sugars: \(coffee.sugar)")
                        .foregroundColor(Color.gray)
                    Spacer()
                }.padding(5)
            }
            Spacer(minLength:5)
            HStack {
                Spacer()
                Text(coffee.cost)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)

            }.padding(40)
            .background(Color.black)
        }
        .navigationTitle("Order for \(coffee.name)")
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct CoffeeDetail_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            NavigationView{
               CoffeeDetail(coffee: testData[0])
            }
        }
    }
}


