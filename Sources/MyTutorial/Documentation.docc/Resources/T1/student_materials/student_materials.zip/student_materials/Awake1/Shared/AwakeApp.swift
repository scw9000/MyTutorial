/*
  Copyright © 2020 Apple Pty Ltd. All rights reserved. Redistribution or public display not permitted without written permission from Apple.
  Created by Simon Wheatley on 20/7/20.
*/

import SwiftUI

@main
struct AwakeApp: App {
    @StateObject private var store = CoffeeStore()
    var body: some Scene {
        WindowGroup {
            ContentView(store: store)
        }
    }
}
