/*
  Copyright © 2020 Apple Pty Ltd. All rights reserved. Redistribution or public display not permitted without written permission from Apple.
  Created by Simon Wheatley on 20/7/20.
*/

import Foundation

class CoffeeStore: ObservableObject {
    @Published var coffees: [Coffee]

    init(coffees: [Coffee] = []) {
        self.coffees = coffees
    }
}

let testStore = CoffeeStore(coffees: testData)
